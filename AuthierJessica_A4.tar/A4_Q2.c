/*
		Greedy Binary Search Tree
    CIS3490 - Assignment 4
    Jessica Authier
    03/25/2019
*/
#include <stdio.h>
#include <stdlib.h>
#include "BST.h"

// This constant can be avoided by explicitly
// calculating height of Huffman Tree
#define MAX_TREE_HT 100

int in = 0;
double total = 0;
int heapSize = 0;
Node * heap[1000];


// allocate a new Node with given word and parability
Node * makeNode(char * word, double prob) {
  Node * newNode = (Node*)malloc(sizeof(Node));
  char * newWord = malloc(sizeof(char)*(strlen(word)+1));
  strcpy(newWord, word);
  newNode->word = newWord;
  newNode->total = prob;
  newNode->left = NULL;
  newNode->right = NULL;
  return newNode;
}

// inserts a node into the tree based on its probability
Node * insert(Node * root, Node * toAdd){
  if (root == NULL){
    return toAdd;
  }
  if (toAdd->total > root->total) {
    // go left
    root->left = insert(root->left, toAdd);
  } else {
    // go right
    root->right = insert(root->right, toAdd);
  }

  return root;
}

// reads in a file and puts the words in a temporary
// tree while counting the occurances of eat word
Node *  readFile(char * filename, Node * root) {
  FILE * fp = fopen(filename, "r");
  if (fp == NULL) {
    printf("Unable to open file\n");
    exit(0);
  }

  int c;
  char word[32];
  int charCount = 0;

  while ((c = fgetc(fp)) != EOF) {
    if (c == ' ' || c == '\n' || c == '\t' || c == '\r' || c == '\0') {
      if (charCount > 0){ // get rid of extra whitespace
        word[charCount] = '\0';
        // look through tree
        root = addNode(root, word);
        charCount = 0;
				total++;
      }
    } else {
      word[charCount] = c;
      charCount++;
    }
  }
  fclose(fp);
  return root;
}

//sets the probabilities and words into arrays in order
void setProbs(Node *root) {
	heap[heapSize] = makeNode(root->word, ((double)root->total/total));
	heapSize++;
}

// searches the tree for a given word
Node * searchTree(Node * root, char * word) {
  if (root == NULL){
    return NULL;
  } else {
    int comp = strcmp(word, root->word);
    if (comp == 0) {
      // same: update the fequency of the word given
      printf("Compared with %s (%.4lf), found.\n", root->word, root->total);
    } else {
			// go left
      printf("Compared with %s (%.4lf), go left subtree.\n", root->word, root->total);
      root->left = searchTree(root->left, word);
      // go right
      printf("Compared with %s (%.4lf), go right subtree.\n", root->word, root->total);
      root->right = searchTree(root->right, word);
    }
  }
  return root;
}

int main(int argc, char * argv[])
{
	char filename[32];
  if (argc > 1){
    strcpy(filename, argv[1]);
  } else {
    printf("Enter the name for the file you would like to search:\n");
    fgets(filename, 32, stdin);
    if (filename[strlen(filename)-1] == '\n') {
      filename[strlen(filename)-1] = '\0';
    }
  }

  Node * temp = NULL;
  temp = readFile(filename, temp);
  traverse(temp, setProbs);
	Node * root = NULL;
	for (int i = 0; i < heapSize; i++) {
		root = insert(root, heap[i]);
	}

	char userInput[32];
  printf("Enter a word:\n");
  fgets(userInput, 32, stdin);
  userInput[strlen(userInput)-1] = '\0';

  Node * res = searchTree(root, userInput);
	if (res == NULL){
		printf("%s not found!\n", userInput);
	}

	deleteTree(temp);
	deleteTree(root);
	return 0;
}
