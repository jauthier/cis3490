
CIS3490 -- Assignment 4
_________________________

Jessica Authier
0849720
03/25/2019
_________________________

To Compile:
-----------

Type "make"

To Run:
-------

Q1 type: "./q1 <filename>"  or "./q1"

Q2 type: "./q2 <filename>"  or "./q2"

_________________________

Limitations:
------------

Q2 does not work correctly as I was confused
about how the coding worked.
