CIS 3490 - Assignment 3

Jessica Authier
0849720

anagramDetect.c
----------------

to compile: gcc anagramDetect.c -o anagram_run
to run: ./anagram_run

stringSearch.c
---------------

to compile: gcc stringSearch.c -o search_run
to run: ./search_run