/*
	stringSearch.c
	CIS3490 A3
	Jessica Authier
	0849720
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

/* Fills the shift table used by Horspool’s and Boyer-Moore algorithms
   Input:
     pattern - The pattern to search for.
     table - The reference table, indexed by the alphabet’s characters and
		 				 filled with shift sizes.
*/
void shifttable(char * p, int * table) {
  int i;
 	int m = strlen(p);
	for (i = 0; i < 1000; ++i) {
		table[i] = m;
	}
	for (i = 0; i < m - 1; ++i){
  	table[(int)p[i]] = m - 1 - i;
	}
}

/* Searches for all the instances of the pattern in the text via horspool's algorithm
   Input:
     text - the entire text to search
     pattern - the pattern to search for
   Output:
     count - the number of matches found
*/
int horspoolSearch(char * text, char * pattern) {
	int i,k;
	int table[1000];
	int n = strlen(text);
	int m = strlen(pattern);
	int count = 0;
	int shifts = 0;
	shifttable(pattern, table);
	i = m-1;
	while(i <= n-1){
		k=0;
 		while(k<=m-1 && pattern[m-1-k] == text[i-k]){ //searh the text backwards comparing the chars
  			k++;
 		}
		if(k==m){ // found a match
			count ++;
			i = i + m - 1;
		} else { // shift
			shifts++;
			if (text[i]<0){
				i = i + 3;
			} else {
				i+=table[(int)text[i]];
			}
		}
	}
	printf("Total shifts from Horspool's algorithm: %d\n", shifts);
	return count;
}

//-------------------------------------------------------------------------

// A utility function to get maximum of two integers
int max (int a, int b) {
  if (a > b) {
    return a;
  }
  return b;
 }

 /* Searches for all the instances of the pattern in the text via Boyer-Moore's algorithm
    Input:
      text - the entire text to search
      pattern - the pattern to search for
    Output:
      count - the number of matches found
 */
int BoyerMooreSearch(char *text, char *pattern) {
	// s is shift of the pattern with respect to text
	int m = strlen(pattern);
	int n = strlen(text);
  int table[1000];
	int count = 0;
	int i,k;
	int shifts = 0;

  // initialize shift table
  shifttable(pattern, table);
	i = m-1;
	while(i <= n-1){
		k=0;
		while(k<=m-1 && pattern[m-1-k] == text[i-k]){ //searh the text backwards comparing the chars
				k++;
		}
		if(k==m){ // found a match
			count ++;
			i ++;
		} else { // shift
			shifts++;
			if (text[i]<0){
				i = i + 3;
			} else {
				i += max(1, table[(int)text[i]]);
			}
		}
	}
	printf("Total shifts from Boyer-Moore's algorithm: %d\n", shifts);
	return count;
}

//----------------------------------------------------------------------


/* Searches for all the instances of the pattern in the text via Brute Force
   Input:
     text - the entire text to search
     pattern - the pattern to search for
   Output:
     count - the number of matches found
*/
int bruteForceSearch(char * text, char * pattern) {
	int i = 0;
	int count = 0;
	int n = strlen(text);
	int m = strlen(pattern);
	int shifts = 0;
	for (i=0;i<n;i++) {
		int j = 0;
		int k = i;
		for (j=0;j<m;j++){
			if (text[k] != pattern[j]) {
				break;
			}
			shifts++;
			k++;
		}
		if (j == m) {
			count ++;
		}
		shifts++;
	}
	printf("Total shifts from Burte Force algorithm: %d\n", shifts);
	return count;
}

//----------------------------------------------------------------------

/* Reads in then file and puts every character in an array
	Inputs:
	  fileName - the name of the file to be read
	Output:
	  text - the array of all the characters from the file
*/
char * readFile(char * fileName) {
	FILE * fp = fopen(fileName, "r");
	if (fp == NULL){
		printf("Invalid file.\n");
		exit(0);
	}

	char * text = malloc(sizeof(char)*3400000);
	printf("here\n");
	int i = 0;
	char c;
	fscanf(fp, "%c",&c);

	while (c != EOF){
		text[i] = c;
		i++;
		int ret =  fscanf(fp, "%c",&c);
		if (ret == EOF)
			break;

	}
	text[i] = '\0';
	return text;
}

int main(int argc, char const *argv[]) {

	char fileName[12] = "data_5.txt";
	char * text = readFile(fileName);
	char pattern[100];

	clock_t t_start, t_end;
	double t_diff;

	printf("Please enter a pattern you wish to search for: ");
	fgets(pattern,100,stdin);

	int len = strlen(pattern) - 1;
	if (pattern[len] == '\n') {
		pattern[len] = '\0';
	}

	t_start = clock();
	int numFound = bruteForceSearch(text,pattern);
	t_end = clock();
	t_diff = (double) (t_end - t_start) / CLOCKS_PER_SEC ;
	printf("%d matche(s) found in %lf seconds using Brute Force Algorithm.\n", numFound, t_diff);

	t_start = clock();
	numFound = horspoolSearch(text,pattern);
	t_end = clock();
	t_diff = (double) (t_end - t_start) / CLOCKS_PER_SEC ;
	printf("%d matche(s) found in %lf seconds using Horspool's Algorithm.\n", numFound, t_diff);

	t_start = clock();
	numFound = BoyerMooreSearch(text,pattern);
	t_end = clock();
	t_diff = (double) (t_end - t_start) / CLOCKS_PER_SEC ;
	printf("%d matche(s) found in %lf seconds using Boyer-Moore's Algorithm.\n", numFound, t_diff);


	return 0;
}
