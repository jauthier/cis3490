
Assignment 3
CIS3490

______________________________

Jessica Authier
0849720

______________________________

 2.4 - Algorithm Analysis
------------------------------

"in"

Horspool:
---------
shifts: 1675010/3540085
Time: 0.03125

BoyerMooreSearch:
-----------------
Shifts: 1675010/3540085
Time: 0.03125

"the"

Horspool:
---------
shifts: 1124082/3593597
Time: 0.03125

BoyerMooreSearch:
-----------------
Shifts: 1134118/3593597
Time: 0.015625

"this"

Horspool:
---------
shifts: 888902/3568389
Time: 0.015625

BoyerMooreSearch:
-----------------
Shifts: 889218/3568389
Time: 0.015625

"where"

Horspool:
---------
shifts: 742029/3342753
Time: 0.015625

BoyerMooreSearch:
-----------------
Shifts: 742103/3342753
Time: 0.015625

"strike"

Horspool:
---------
shifts: 610953/3485797
Time: 0.000000

BoyerMooreSearch:
-----------------
Shifts: 610955/3485797
Time: 0.000000

"program"

Horspool:
---------
shifts: 534218/3384917
Time: 0.000000

BoyerMooreSearch:
-----------------
Shifts: 537466/3384917
Time: 0.000000

"publish"

Horspool:
---------
shifts: 537044/3353593
Time: 0.015625

BoyerMooreSearch:
-----------------
Shifts: 537106/3353593
Time: 0.000000

"Colleges"

Horspool:
---------
shifts: 469027/3326983
Time: 0.015625

BoyerMooreSearch:
-----------------
Shifts: 469031/3326983
Time: 0.000000

"inability"

Horspool:
---------
shifts: 441447/3547536
Time: 0.000000

BoyerMooreSearch:
-----------------
Shifts: 441462/3547536
Time:  0.015625

"University"

Horspool:
---------
shifts: 429295/3325733
Time: 0.000000

BoyerMooreSearch:
-----------------
Shifts: 431148/3325733
Time:  0.000000

Comparison:
-----------

From the analysis above it appears that the Boyer-Moore algorithm
does on average more shifts than the Horspool Algorithm. The time
for running each algorithm were very close, with Horspool a bit faster
with smaller strings and Boyer-Moore a little faster for longer
strings. Both however were always faster or equal to the
Brute Force method.

______________________________

Compile/Run
------------

anagram.c
----------------

to compile: make anagram
to run: ./anagram

stringSearch.c
---------------

to compile: make search
to run: ./search
