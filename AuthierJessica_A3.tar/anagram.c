/*
	anagram.c
	CIS3490 A3
	Jessica Authier
	0849720
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void mergeSort(int ** intArr, char ** dict, int l, int r);
void merge(int ** intArr, char ** dict, int l1, int r1, int l2, int r2);

/*
  Input: f[] --> The character frequencies of the given strings
         b[] --> A chracter string to compare to the given string

  Output: 1 if the string b is an anagram of the user provided string,
          and 0 if it is not
*/

int check_anagram (int f1[], int f2[]) {
  int count = 0;
  // Comparing frequency of characters
  for (count = 0; count < 10; count++) {
    if (f1[count] != f2[count])
      return 0;
  }
  return 1;
}

int bruteForceDetection(char * str, char * filename) {
  FILE * fp = fopen(filename, "r");
	if (fp == NULL){
		printf("Invalid file.\n");
		exit(0);
	}

  int count = 0;
  int i = 0;
  char hold[20];
	char c;
  int frequency[10] = {0};

  while (str[i] != '\0' && str[i] != '\n') {
    frequency[str[i]-'0'] = frequency[str[i]-'0']+1;
    i++;
  }

  i = 0;
  while ((c = fgetc(fp)) != EOF) {
    if (c==' '||c=='\n'||c=='\r'){
      // char s = getchar();
      hold[i] = '\0';
      int f2[10] = {0};
      int m=0;

      // Calculate frequency of characters of the string b
      while (hold[m] != '\0' && hold[m] != '\n') {
        f2[hold[m]-'0']++;
        m++;
      }
      int isanagram = check_anagram(frequency, f2);
      if (isanagram == 1){
        count++;
        printf("%s\n", hold);
      }
      i=0;
    } else {
      hold[i] = c;
      i++;
    }
  }
  fclose(fp);
  return count;
}

void mergeSort(int ** intArr, char ** dict, int l, int r) {
  int mid;
  if (l<r){
    mid = (r+l)/2;
    mergeSort(intArr, dict, l, mid);
    mergeSort(intArr, dict, mid+1, r);
    merge(intArr, dict, l, mid, mid+1, r);
  }
}

void merge(int ** intArr, char ** dict, int l1, int r1, int l2, int r2) {
  int * temp1[30000];	//array used for merging
  char * temp2[30000];
	int i,j,k;
	i=l1;	//beginning of the first list
	j=l2;	//beginning of the second list
	k=0;

	while (i<=r1 && j<=r2)	{ //while elements in both lists
    int m = 0;
    for (m = 0; m < 10; m++) {
      if (intArr[i][m] < intArr[j][m]){
        temp1[k] = intArr[i];
        temp2[k] = dict[i];
        k++;
        i++;
        break;
      } else if (intArr[i][m] > intArr[j][m]){
        temp1[k] = intArr[j];
        temp2[k] = dict[j];
        k++;
        j++;
        break;
      } else {
        if (m == 9) {
          temp1[k] = intArr[j];
          temp2[k] = dict[j];
          k++;
          j++;
          break;
        }
      }
    }
  }

	while (i<=r1) { //copy remaining elements of the first list
    temp1[k]=intArr[i];
    temp2[k] = dict[i];
    k++;
    i++;
  }

	while (j<=r2) { //copy remaining elements of the second list
    temp1[k]=intArr[j];
    temp2[k] = dict[j];
    k++;
    j++;
  }

	for (i=l1,j=0;i<=r2;i++,j++) { //Transfer elements from temp1[] back to a[]
    intArr[i] = temp1[j];
    dict[i] = temp2[j];
  }
}

int presortDecection(char * str, int ** intArr, char ** dict) {
  int count = 0;
  int f[10] = {0};
  int i = 0;
  int foundMatch = 0;
  // Calculate frequency of characters of the string b
  while (str[i] != '\0' && str[i] != '\n') {
    f[str[i]-'0']++;
    i++;
  }

  for (i = 0; i < 30000; i++) {
    int isanagram = check_anagram(f, intArr[i]);
    if (isanagram == 1) {
      foundMatch = 1;
      printf("%s\n", dict[i]);
      count ++;
    } else {
      if (foundMatch == 1){
        break;
      }
    }
  }

  return count;
}

void readFile(char * filename, int ** intArr, char ** dict){
  FILE * fp = fopen(filename, "r");
	if (fp == NULL){
		printf("Invalid file.\n");
		exit(0);
	}

  char c;
  int i=0; // iterate through the intArr
  int j=0; // iterate through char in each string
  char hold[11];

  intArr[i] = malloc(sizeof(int)*10);

  while ((c = fgetc(fp)) != EOF) {
    if (c==' '||c=='\n'||c=='\r'){
      hold[j] = '\0';
      dict[i] = malloc(sizeof(char)*(strlen(hold)+2));
      strcpy(dict[i],hold);
      j=0;
      i++;
      intArr[i] = malloc(sizeof(int)*10);
    } else {
      intArr[i][c-'0']++;
      hold[j] = c;
      j++;
    }
  }
  fclose(fp);
}

int main(int argc, char const *argv[]) {
  char first[20];
	char filename[20];
  clock_t t_start, t_end;
	double t_diff;

  if (argc > 1){
    strcpy(filename, argv[1]);
  } else {
    strcpy(filename, "data_4.txt");
  }

  printf("Please enter a string that you want to find the anagrams of: ");
	fgets(first,20,stdin);

  int len = strlen(first) - 1;
	if (first[len] == '\n'){
    first[len] = '\0';
  }

  char * str = malloc(sizeof(char)*(len+1));
  strcpy(str,first);

  printf("Brute Force Anagram Detection Results: \n");
  t_start = clock();
  int num = bruteForceDetection(first, filename);
  t_end = clock();
  t_diff = (double) (t_end - t_start)/ CLOCKS_PER_SEC;
  printf("There were %d anagrams found in %lfms.\n",num,t_diff);
  printf("---------------------------------------------\n");

  // read in the file and convert the strings to their character frequencies
  int ** intArr = malloc(sizeof(int*)*30000);
  char ** dict = malloc(sizeof(char *)*30000);
  readFile(filename, intArr, dict);

  printf("Sorting the strings\n");
  t_start = clock();
  mergeSort(intArr, dict, 0, 30000);
  t_end = clock();
  t_diff = (double) (t_end - t_start)/ CLOCKS_PER_SEC;
  printf("Sort completed in %lfms.\n", t_diff);
  printf("---------------------------------------------\n");

  printf("Pre-Sort Anagram Decection Results: \n");
  t_start = clock();
  num = presortDecection(first, intArr, dict);
  t_end = clock();
  t_diff = (double) (t_end - t_start)/ CLOCKS_PER_SEC;
  printf("There were %d anagrams found in %lfms.\n",num,t_diff);

  free(str);
  free(intArr);
  return 0;
}
